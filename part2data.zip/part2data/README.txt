How to run part two:
Run the following line in the terminal - please note that the csv files should be in the same folder
python3 a3part2.py breast-cancer-training.csv breast-cancer-test.csv
